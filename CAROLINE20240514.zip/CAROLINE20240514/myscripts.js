var myObj, i, j="";
var tujuan ="";
var y = "";
var id = "";
var category_id = "";
var parent_id = "";
var category_name = "";
var parent_name = "";
var idrias = "";
var category_idrias = "";
var parent_idrias = "";
var category_namerias = "";
var parent_namerias = "";
var ipa = "";
var pass="";
var rias="";
var akhir="";
var json= "";
var noipa= 0;
var nopass=0;
var norias=0;
var jawaban;
var txt="";
var berhasil=0;

function pertanyaan (tujuan){
		var getJSON = function(url, callback) {
			var xhr = new XMLHttpRequest();
			xhr.open('GET', url, true);
			xhr.responseType = 'json';
			xhr.onload = function() {
				var status = xhr.status;
				if (status === 200) {
					callback(null, xhr.response);
				} else {
					callback(status, xhr.response);
				}
			};
			xhr.send();
		};

		getJSON(tujuan,
			function(err, data) {
				if (err !== null) {
					alert('Something went wrong: ' + err);
				} else {
					if (data == null) {
						alert('Something went wrong: ' + data);
					}
					else {
						var lastdata = data.data.length;
						console.log(lastdata);
					for (i in data.data) {
						if(data.data[i].category.parent_category.name == "PassionTrack"){
							category_id += data.data[i].category_id+".";
							parent_id += data.data[i].category.parent+".";
							pass += data.data[i].question+"|";
							id += data.data[i].id+".";
							category_name += data.data[i].category.name+".";
							parent_name += data.data[i].category.parent_category.name+".";
							nopass++;
							
						}						
						if(data.data[i].category.parent_category.name != "PassionTrack" && data.data[i].category.parent_category.name != "RIASEC"){
							category_id += data.data[i].category_id+".";
							parent_id += data.data[i].category.parent+".";
							ipa += data.data[i].question+"|";
							id += data.data[i].id+".";
							category_name += data.data[i].category.name+".";
							parent_name += data.data[i].category.parent_category.name+".";
							noipa++;
						}
					}
					for (z in data.data){
						if(data.data[z].category.parent_category.name == "RIASEC"){
							category_idrias += data.data[z].category_id+".";
							parent_idrias += data.data[z].category.parent+".";
							rias += data.data[z].question+"|";
							idrias += data.data[z].id+".";
							category_namerias += data.data[z].category.name+".";
							parent_namerias += data.data[z].category.parent_category.name+".";
							norias++;
						}
						if(z==lastdata-1)
						{
							id += idrias;
							category_id += category_idrias;
							category_name += category_namerias;
							parent_name += parent_namerias;
							parent_id += parent_idrias;
						}
					}
					console.log(idrias);
					y = data.data[i].user_id+".";
					// console.log(category_name);
					// console.log(noipa);
					// console.log(norias);
					console.log(data);
					// if(typeof c2_callFunction === "function"){
					if (self.c2_callFunction){
    				self.c2_callFunction("pert");
					console.log("called");
					}
				}

			}
			});
}

function convertjson(jawaban){
		var jawab;
		nopass = 0;
		norias = 0;
		noipa = 0;
        jawab = jawaban;
		console.log(jawab);
		// var parsedJson = JSON.parse(jawaban);
		var json = JSON.stringify(jawab);		
		console.log(json);
		akhir = json;
	}
