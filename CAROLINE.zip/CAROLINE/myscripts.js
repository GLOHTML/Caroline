var myObj, i, j="";
var tujuan ="";
var y = "";
var id = "";
var category_id = "";
var parent_id = "";
var category_name = "";
var parent_name = "";
var ipa = "";
var pass="";
var rias="";
var akhir="";
var json= "";
var noipa= 0;
var nopass=0;
var norias=0;
var jawaban;
var txt="";
var berhasil=0;
function pertanyaan(tujuan){
		var getJSON = function(url, callback) {
			var xhr = new XMLHttpRequest();
			xhr.open('GET', url, true);
			xhr.responseType = 'json';
			xhr.onload = function() {
				var status = xhr.status;
				if (status === 200) {
					callback(null, xhr.response);
				} else {
					callback(status, xhr.response);
				}
			};
			xhr.send();
		};

		getJSON(tujuan,
			function(err, data) {
				if (err !== null) {
					alert('Something went wrong: ' + err);
				} else {
					for (i in data.data) {
						if(data.data[i].category.parent_category.name == "PassionTrack"){
							category_id += data.data[i].category_id+".";
							parent_id += data.data[i].category.parent+".";
							pass += data.data[i].question+".";
							id += data.data[i].id+".";
							category_name += data.data[i].category.name+".";
							parent_name += data.data[i].category.parent_category.name+".";
							nopass++;
							
						}
						if(data.data[i].category.parent_category.name == "RIASEC"){
							category_id += data.data[i].category_id+".";
							parent_id += data.data[i].category.parent+".";
							rias += data.data[i].question+".";
							id += data.data[i].id+".";
							category_name += data.data[i].category.name+".";
							parent_name += data.data[i].category.parent_category.name+".";
							norias++;
						}
						if(data.data[i].category.parent_category.name != "PassionTrack" && data.data[i].category.parent_category.name != "RIASEC"){
							category_id += data.data[i].category_id+".";
							parent_id += data.data[i].category.parent+".";
							ipa += data.data[i].question+".";
							id += data.data[i].id+".";
							category_name += data.data[i].category.name+".";
							parent_name += data.data[i].category.parent_category.name+".";
							noipa++;
						}
					}
					y = data.data[i].user_id+".";
					console.log(category_name);
					console.log(noipa);
					console.log(norias);
					console.log(nopass);
					if(typeof c2_callFunction === "function"){
					c2_callFunction('pert', [event.origin]);
					console.log("called");
					}
				}
			});
}
function jadilahjson(jawaban){
		var jawab;
		nopass = 0;
		norias = 0;
		noipa = 0;
        jawab = jawaban;
		console.log(jawaban);
		var json = JSON.stringify(jawab);
		akhir = json;
		console.log(json);
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
		berhasil = 200;
		}
		else 
		berhasil = 10;
		}
		xhttp.open("POST", "http://caroline.psikologie.com/testminat/", true);
		xhttp.send(json);
		console.log(berhasil);
}